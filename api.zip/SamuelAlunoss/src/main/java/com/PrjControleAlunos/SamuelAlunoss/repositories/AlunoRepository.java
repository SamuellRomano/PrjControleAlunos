package com.PrjControleAlunos.SamuelAlunoss.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.PrjControleAlunos.SamuelAlunoss.entities.Aluno;


public interface AlunoRepository extends JpaRepository<Aluno, Long>{


}
