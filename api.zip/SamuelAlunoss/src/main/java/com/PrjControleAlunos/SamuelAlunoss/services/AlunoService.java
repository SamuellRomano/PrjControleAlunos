package com.PrjControleAlunos.SamuelAlunoss.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.PrjControleAlunos.SamuelAlunoss.entities.Aluno;
import com.PrjControleAlunos.SamuelAlunoss.repositories.AlunoRepository;



@Service
public class AlunoService {
	
private final AlunoRepository Alunorepository;
	
@Autowired
public AlunoService(AlunoRepository Alunorepository) {
	this.Alunorepository = Alunorepository;
}

public Aluno saveAluno(Aluno aluno) {
	return Alunorepository.save(aluno);
}

public Aluno getAlunoById(long idAluno) {
	return Alunorepository.findById(idAluno).orElse(null);
}

public List<Aluno> getAllAluno(){
	return Alunorepository.findAll();
}

public void deleteAluno(Long idAluno) {
	Alunorepository.deleteById(idAluno);
}


}
